package com.nizam.simpletodo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

data class Task(val id: Long, val title: String, val done: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { TodoScreen() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoScreen() {
    val tasks: SnapshotStateList<Task> = remember { mutableStateListOf() }
    var input by remember { mutableStateOf("") }

    fun addTask() {
        val text = input.trim()
        if (text.isNotEmpty()) {
            tasks.add(0, Task(System.currentTimeMillis(), text))
            input = ""
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Simple Todo") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Naya task likho") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { addTask() }) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                }
            }

            Spacer(Modifier.height(16.dp))

            if (tasks.isEmpty()) {
                Text("Abhi koi task nahi hai.", style = MaterialTheme.typography.bodyMedium)
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks, key = { it.id }) { task ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = task.done,
                                onCheckedChange = { checked ->
                                    val i = tasks.indexOfFirst { it.id == task.id }
                                    if (i >= 0) tasks[i] = task.copy(done = checked)
                                }
                            )
                            Text(
                                text = task.title,
                                modifier = Modifier.weight(1f),
                                textDecoration = if (task.done) TextDecoration.LineThrough else null
                            )
                            IconButton(onClick = { tasks.remove(task) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}
